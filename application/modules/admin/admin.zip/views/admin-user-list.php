<?php $this->load->view('inc/header'); ?>

    <!-- Header Layout Content -->
    <div class="mdk-header-layout__content">
        <div data-push data-responsive-width="992px" class="mdk-drawer-layout js-mdk-drawer-layout">
            <div class="mdk-drawer-layout__content page ">

                <div class="container-fluid page__container">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="student-dashboard.html">Home</a></li>
                        <li class="breadcrumb-item active">User</li>
                    </ol>
                    <!--<h1 class="h2">User</h1>-->
                    <div class="media align-items-center mb-headings">
                        <div class="media-body">
                            <h1 class="h2">User</h1>
                        </div>
                        <div class="media-right">
                            <a href="<?php echo site_url('admin/admin_user_form'); ?>" class="btn btn-danger">Add New User</a>
                        </div>
                    </div>
                   
                    <!-- Search -->
                    <div class="flex search-form form-control-rounded search-form--light mb-2 ui-widget" style="min-width: 200px;">
                        <input type="text" class="form-control" placeholder="Search user" id="users" >
                        <button class="btn pr-3" type="button" role="button"><i class="material-icons">search</i></button>
                    </div>
                    <br>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <div class="media align-items-center">
                                        <div class="media-body">
                                            <h4 class="card-title">Employees</h4>
                                            <p class="card-subtitle">List of all Employess</p>
                                        </div>
                                        <div class="media-right">
                                            <a href="<?php echo site_url('admin/admin_user_form/emp'); ?>" class="btn btn-primary btn-sm"><i class="material-icons">add</i> Add</a>
                                        </div>
                                    </div>
                                </div>
                                
                                 <table class="table   thead-border-top-0 mydataTable text-center">
<thead class="bg-white">
<tr>
    <th>Emp Id</th>
    <th>Picture</th>
    <th>Name & Email</th>
     
    <th>designation</th>
    <th>Status</th>
    <th>Action</th>
</tr>
</thead>
<tbody class="list">
 <?php  foreach ($get_employees as  $employess): ?>
<tr>
    <td class="text-right">#id</td>
    <td>
         
            <div class="avatar avatar-sm mr-3">
                
                <img src="<?php echo base_url(); ?>admin-assets/images/all-users/<?php echo $employess->profile_image; ?>" alt="" width="40" class="avatar-img rounded-circle">
            </div>
           
         
    </td>
    <td>
         <div class="media-body">
                <a href="<?php echo site_url(); ?>admin/view_user/<?php echo $employess->id; ?>" class="text-body"><strong><?php echo $employess->first_name.' '.$employess->last_name; ?></strong></a><br>
                <span class="text-muted js-lists-values-employee-title"><?php echo $employess->email; ?></span>
            </div>
    </td>
    <td class="text-right">designation</td>
    <td>
        <div class="form-group">
          <select class="form-control" id="sel1">
            <option value="" class="badge badge-soft-danger" <?php if($employess->user_status == ''){ echo 'selected'; } ?>>Inactive</option>
            <option value="active" class="badge badge-soft-success" <?php if($employess->user_status == 'active'){ echo 'selected'; } ?> >Active</option>
          </select>
        </div>
    </td>
    
    <td>
        <a href="<?php echo site_url(); ?>admin/view_user/<?php echo $employess->id; ?>" class="btn btn-info btn-sm text-white">Edit</a>
        <a href="#" class="btn btn-success btn-sm text-white">Send Message</a>

       <!--  <a type="button" class="btn btn-info btn-sm text-white">View</a> -->

    </td>
</tr>
<?php endforeach; ?>
 
</tbody>
</table>
                                 
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">
                                    <div class="media align-items-center">
                                        <div class="media-body">
                                            <h4 class="card-title">Managements</h4>
                                            <p class="card-subtitle">List of all Managements</p>
                                        </div>
                                        <div class="media-right">
                                            <a href="<?php echo site_url('admin/admin_user_form/mgnts'); ?>" class="btn btn-primary btn-sm"><i class="material-icons">add</i> Add</a>
                                        </div>
                                    </div>
                                </div>



                                <ul class="list-group list-group-fit">
                                    <?php foreach ($get_manager_list as  $manager): ?>
                                    <li class="list-group-item forum-thread">
                                        <div class="media align-items-center">
                                            <div class="media-left">
                                                <div class="forum-icon-wrapper">
                                                    <img src="<?php echo base_url(); ?>admin-assets/images/all-users/<?php echo $manager->profile_image; ?>" alt="" width="40" class="rounded-circle" style="min-height: 40px;">
                                                </div>
                                            </div>
                                            <div class="media-body">
                                                <div class="d-flex align-items-center">
                                                    <a href="<?php echo site_url(); ?>admin/view_user/<?php echo $manager->id; ?>" class="text-body"><strong><?php echo $manager->first_name.' '.$manager->last_name; ?></strong></a>
                                                    <small class="ml-auto text-muted">
                                                        <?php  $this->admin_m->time_diffrent($manager->created_at); ?><br><span style="color: green;">
                                                     <?php   $empdob = $manager->dob;
                                                        $d=strtotime("+2 Days");
                                                        $current_ndate = date("Y-m-d", $d);
                                                        $current_date = date("Y-m-d");
                                                        if($empdob == $current_ndate) {
                                                            echo 'Birthday Coming soon';
                                                        }
                                                        if($current_date == $empdob){
                                                            echo 'Today Is Birthday' ;
                                                        }
                                                     ?>
                                                 </span>
                                                    </small>
                                                    <div class="dropdown left-0 pl-2">
                                                        <a href="#" class="dropdown-toggle text-muted" data-caret="false" data-toggle="dropdown">
                                                            <i class="material-icons">more_vert</i>
                                                        </a>
                                                        <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#">Add Tags</a>
                                                            <a class="dropdown-item" href="#">Send Message</a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <p class="text-black-70"><?php echo $manager->email; ?></p>
                                            </div>
                                        </div>
                                    </li>
                                    <?php endforeach ?>
 

                                </ul>
                            </div>
                        </div>
                         <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <div class="media align-items-center">
                                        <div class="media-body">
                                            <h4 class="card-title">Students</h4>
                                            <p class="card-subtitle">List of all Students</p>
                                        </div>
                                        <div class="media-right">
                                            <a href="<?php echo site_url('admin/admin_user_form/user'); ?>" class="btn btn-primary btn-sm"><i class="material-icons">add</i> Add</a>
                                        </div>
                                    </div>
                                </div>



                                <ul class="list-group list-group-fit">
                                    <?php foreach ($get_users_list as  $users): ?>
                                    <li class="list-group-item forum-thread">
                                        <div class="media align-items-center">
                                            <div class="media-left">
                                                <div class="forum-icon-wrapper">
                                                    <img src="<?php echo base_url(); ?>admin-assets/images/all-users/<?php echo $users->profile_image; ?>" alt="" width="40" class="rounded-circle" style="min-height: 40px;">
                                                </div>
                                            </div>
                                            <div class="media-body">
                                                <div class="d-flex align-items-center">
                                                    <a href="<?php echo site_url(); ?>admin/view_user/<?php echo $users->id; ?>" class="text-body"><strong><?php echo $users->first_name.' '.$users->last_name; ?></strong></a>
                                                    <small class="ml-auto text-muted"> <?php  $this->admin_m->time_diffrent($users->created_at); ?><br><span style="color: green;">
                                                     <?php   $empdob = $users->dob;
                                                        $d=strtotime("+2 Days");
                                                        $current_ndate = date("Y-m-d", $d);
                                                        $current_date = date("Y-m-d");
                                                        if($empdob == $current_ndate) {
                                                            echo 'Birthday Coming soon';
                                                        }
                                                        if($current_date == $empdob){
                                                            echo 'Today Is Birthday' ;
                                                        }
                                                     ?>
                                                 </span></small>
                                                    <div class="dropdown left-0 pl-2">
                                                        <a href="#" class="dropdown-toggle text-muted" data-caret="false" data-toggle="dropdown">
                                                            <i class="material-icons">more_vert</i>
                                                        </a>
                                                        <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#">Add Tags</a>
                                                            <a class="dropdown-item" href="#">Send Message</a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <p class="text-black-70"><?php echo $users->email; ?></p>
                                            </div>
                                        </div>
                                    </li>
                                    <?php endforeach ?>
 

                                </ul>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
<?php $this->load->view('inc/sidebar'); ?> 
<?php $this->load->view('inc/footer'); ?>