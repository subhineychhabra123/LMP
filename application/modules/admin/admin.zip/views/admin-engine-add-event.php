<?php $this->load->view('inc/header'); ?>

    <!-- Header Layout Content -->
    <div class="mdk-header-layout__content">

        <div data-push data-responsive-width="992px" class="mdk-drawer-layout js-mdk-drawer-layout">
            <div class="mdk-drawer-layout__content page ">

                <div class="container-fluid page__container">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="admin-dashboard.html">Home</a></li>
                        <li class="breadcrumb-item"><a href="#">Event Engine</a></li>
                        <li class="breadcrumb-item active">Add Event</li>
                    </ol>
                    <div class="media align-items-center mb-headings">
                        <div class="media-body">
                            <h1 class="h2">Add Event</h1>
                        </div>
                        <div class="media-right">
                            <a href="#" class="btn btn-danger">SAVE</a>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <form action="#">
                                <div class="form-group row">
                                    <label for="avatar" class="col-sm-3 col-form-label form-label">Preview</label>
                                    <div class="col-sm-9">
                                        <div class="media align-items-center">
                                            <div class="media-left">
                                                <img src="assets/images/event-4.jpg" alt="" width="100" class="rounded">
                                            </div>
                                            <div class="media-body">
                                                <div class="custom-file" style="width: auto;">
                                                    <input type="file" id="avatar" class="custom-file-input">
                                                    <label for="avatar" class="custom-file-label">Choose file</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="title" class="col-md-3 col-form-label form-label">Event Title</label>
                                    <div class="col-md-6">
                                        <input id="title" type="text" class="form-control" placeholder="Write an event title">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="course" class="col-md-3 col-form-label form-label">Category</label>
                                    <div class="col-md-4">
                                        <select id="course" class="custom-control custom-select form-control">
                                            <option value="#">HTML</option>
                                            <option value="#">Angular JS</option>
                                            <option value="#" selected>Vue.js</option>
                                            <option value="#">CSS / LESS</option>
                                            <option value="#">Design / Concept</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="course" class="col-md-3 col-form-label form-label">Event Date</label>
                                    <div class="col-md-4">
                                        <input type="text" class="form-control" placeholder="Enter date">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="course" class="col-md-3 col-form-label form-label">Event Time</label>
                                    <div class="col-md-4">
                                        <input type="text" class="form-control" placeholder="Enter time">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="course" class="col-md-3 col-form-label form-label">Location</label>
                                    <div class="col-md-4">
                                        <input type="text" class="form-control" placeholder="Enter loaction">
                                    </div>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>

            </div>
<?php $this->load->view('inc/sidebar'); ?>   

<?php $this->load->view('inc/footer'); ?>