<?php $this->load->view('inc/header'); ?>
    <!-- Header Layout Content -->
    <div class="mdk-header-layout__content">

        <div data-push data-responsive-width="992px" class="mdk-drawer-layout js-mdk-drawer-layout">
            <div class="mdk-drawer-layout__content page ">

                <div class="container-fluid page__container">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="student-dashboard.html">Home</a></li>
                        <li class="breadcrumb-item active">Approval</li>
                    </ol>
                    <h1 class="h2">Approval</h1>

                    <div class="card">
                        <div class="card-header">
                            <div class="media align-items-center">
                                <div class="media-body">
                                    <h4 class="card-title">Approval list</h4>
                                </div>
                            </div>
                        </div>
                      
 
 <table class="table   thead-border-top-0 mydataTable text-center">
                                            <thead class="bg-white">
                                                <tr>
                                                    <th>User</th>
                                                    <th>Manager Name</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody class="list">

                                                <tr>
                                                    <td>
                                                        <div class="media align-items-center">
                                                            <div class="avatar avatar-sm mr-3">
                                                                
                                                                <img src="<?php echo base_url(); ?>admin-assets/images/256_rsz_nicolas-horn-689011-unsplash.jpg" alt="" width="40" class="avatar-img rounded-circle">
                                                            </div>
                                                            <div class="media-body">
                                                                <strong class="js-lists-values-employee-name"><a href="view_user/93">Jenell D. Matney</a></strong><br>
                                                                <span class="text-muted js-lists-values-employee-title">Lorem ipsum dolor amet consectetur.</span>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="text-right"><a href="view_user/96">Manager Name</a></td>
                                                    <td class="text-right">
                                                        <a type="button" class="btn btn-success btn-sm text-white">Approve</a>
                                                        <a type="button" class="btn btn-danger btn-sm text-white">Ignore</a>
                                                       <!--  <a type="button" class="btn btn-info btn-sm text-white">View</a> -->

                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div class="media align-items-center">
                                                            <div class="avatar avatar-sm mr-3">
                                                                
                                                                <img src="<?php echo base_url(); ?>admin-assets/images/256_rsz_sharina-mae-agellon-377466-unsplash.jpg" alt="" width="40" class="avatar-img rounded-circle">
                                                            </div>
                                                            <div class="media-body">
                                                                <strong class="js-lists-values-employee-name"><a href="view_user/93">Sherri J. Cardenas</a></strong><br>
                                                                <span class="text-muted js-lists-values-employee-title">Lorem ipsum dolor amet consectetur.</span>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="text-right"><a href="view_user/96">Manager Name</a></td>
                                                    <td class="text-right">
                                                        <a type="button" class="btn btn-success btn-sm text-white">Approve</a>
                                                        <a type="button" class="btn btn-danger btn-sm text-white">Ignore</a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div class="media align-items-center">
                                                            <div class="avatar avatar-sm mr-3">
                                                                
                                                                <img src="<?php echo base_url(); ?>admin-assets/images/256_rsz_karl-s-973833-unsplash.jpg" alt="" width="40" class="avatar-img rounded-circle">
                                                            </div>
                                                            <div class="media-body">
                                                                <strong class="js-lists-values-employee-name"><a href="view_user/93">Sherri J. Cardenas</a></strong><br>
                                                                <span class="text-muted js-lists-values-employee-title">Lorem ipsum dolor amet consectetur.</span>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="text-right"><a href="view_user/96">Manager Name</a></td>
                                                    <td class="text-right">
                                                       <a type="button" class="btn btn-success btn-sm text-white">Approve</a>
                                                        <a type="button" class="btn btn-danger btn-sm text-white">Ignore</a>
                                                    </td>
                                                </tr>

                                                

                                            </tbody>
                                        </table>
 
                    </div>


                </div>

            </div>
 
<?php $this->load->view('inc/sidebar'); ?>   

<?php $this->load->view('inc/footer'); ?>