<?php $this->load->view('inc/header'); ?>

    <!-- Header Layout Content -->
    <div class="mdk-header-layout__content">
         <div data-push data-responsive-width="992px" class="mdk-drawer-layout js-mdk-drawer-layout">
            <div class="mdk-drawer-layout__content page ">
                <div class="container-fluid page__container">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="admin-dashboard.html">Home</a></li>
                        <li class="breadcrumb-item"><a href="admin-view-course.html">View Courses</a></li>
                        <li class="breadcrumb-item active">Edit Courses</li>
                    </ol>
                    <?php if($this->session->flashdata('error') ||  validation_errors()){ ?>
                                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                       <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                           <span aria-hidden="true">×</span>
                                       </button>
                                       <?php echo $this->session->flashdata('error'); ?>
                                       <?php echo validation_errors(); ?> 
                                   </div>
                                <?php } ?>
                                <?php if($this->session->flashdata('success')){ ?>  
                                   <div class="alert alert-success alert-dismissible fade show" role="alert">
                                       <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                           <span aria-hidden="true">×</span>
                                       </button>
                                      <?php echo $this->session->flashdata('success'); ?>
                                   </div>
                                <?php } ?>
                    <div class="media align-items-center mb-headings">
                        <div class="media-body">
                            <h1 class="h2">Edit Course</h1>
                        </div>
                         
                          <form action="<?php echo site_url('admin/update_course_simple_info'); ?>" method="post">
                            <input type="hidden" name="ids" value="<?php echo $this->uri->segment(3); ?>">
                        <div class="media-right">
                            <input type="submit"  class="btn btn-danger" name="Update" value="Update"></a>
                        </div>
                    </div>
                   
                    <div class="row">
                        <div class="col-md-8">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Basic Information</h4>
                                </div>
                                <div class="card-body">
                                   
                                    <div class="form-group">
                                        <label class="form-label" for="title">Title</label>
                                        <input type="text" id="title" class="form-control" name="title09" placeholder="Write a title" value="<?php echo $single_course->title; ?>">
                                    </div>

                                    <div class="form-group mb-0">
                                        <label class="form-label">Description</label>
                                        <input type="hidden" name="descri" id="current_text">

                                        <div style="height: 150px;" data-toggle="quill" id="text_editor"  data-quill-placeholder="Quill WYSIWYG editor" data-quill-modules-toolbar='[["bold", "italic"], ["link", "blockquote", "code", "image"], [{"list": "ordered"}, {"list": "bullet"}]]'>
                                            <?php echo $single_course->descri; ?>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Lessons</h4>
                                </div>
                                <div class="card-body">
                                     
                                    <p><a href="!#" class="btn btn-primary" data-toggle="modal" data-target="#modal-center">Add Lesson <i class="material-icons">add</i></a></p>
                                    <div class="nestable" id="nestable-handles-primary">
                                        <ul class="nestable-list"> 
                                            <?php foreach ($selected_lesson as  $lesson): ?>
                                                 <li class="nestable-item nestable-item-handle" data-id="2">
                                                <div class="nestable-handle"><i class="material-icons">menu</i></div>
                                                <div class="nestable-content">
                                                    <div class="media align-items-center">
                                                        <div class="media-left">
                                                            <img src="<?php echo base_url(); ?>/admin-assets/images/course/<?php echo $lesson->img; ?>" alt="" width="100" class="rounded">
                                                        </div>
                                                        <div class="media-body">
                                                            <h5 class="card-title h6 mb-0">
                                                                <a href="#"><?php echo $lesson->title; ?></a>
                                                            </h5>
                                                            <small class="text-muted"><?php  $this->admin_m->time_diffrent($lesson->created_at); ?></small>
                                                        </div>
                                                        <div class="media-right">
                                                              <a href="#" class="btn btn-white btn-sm"><i class="material-icons">edit</i></a>
                                                              <!-- <a href="#" class="btn btn-white btn-sm"><i class="material-icons">delete</i></a> -->
                                                        </div>
                                                    </div>
                                                </div>
                                            </li>
                                            <?php endforeach ?>
                                           
                                           
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card">
                                <div class="embed-responsive embed-responsive-16by9">
                                    <iframe class="embed-responsive-item" src="<?php echo $single_course->video_id; ?>" allowfullscreen=""></iframe>
                                </div>
                                <div class="card-body">
                                    <input type="text" class="form-control" name="videoid09" value="<?php echo $single_course->video_id; ?>" />
                                </div>
                            </div>
                            <div class="card  card-body">
                                <div class="card-header">
                                    <h4 class="card-title">Meta</h4>
                                    <p class="card-subtitle">Extra Options </p>
                                </div>

                                
                                    <div class="form-group">
                                        <label class="form-label" for="category">Category</label>
                                        <select id="category" class="custom-select form-control" name="course">
                                             <?php foreach ($all_category as  $cate): ?>
                                             <option value="<?php echo $cate->id; ?>" <?php if($cate->id == $single_course->course){ echo 'selected'; } ?> ><?php echo $cate->category; ?></option>
                                            <?php endforeach ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label" for="duration">Duration</label>
                                        <input type="text" id="duration" class="form-control" name="duration" placeholder="No. of Days" value="<?php echo $single_course->duration; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label" for="start">Start Date</label>
                                        <input id="start" type="text" class="form-control" name="start_time" placeholder="Start Date" data-toggle="flatpickr" value="<?php echo $single_course->start_date; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label" for="end">End Date</label>
                                        <input id="end" type="text" class="form-control" name="end_time" placeholder="Start Date" data-toggle="flatpickr" value="<?php echo $single_course->end_date; ?>">
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>

                </div>

            </div>

<?php $this->load->view('inc/sidebar'); ?>   

<?php $this->load->view('inc/footer'); ?>
<script type="text/javascript">
 
$( "#text_editor" ).mouseout(function() {
   var text_area = $(this).text();
    
   $('#current_text').val(text_area);
});
</script>