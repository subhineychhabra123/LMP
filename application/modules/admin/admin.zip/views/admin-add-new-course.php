<?php $this->load->view('inc/header'); ?>

    <!-- Header Layout Content -->
    <div class="mdk-header-layout__content">

        <div data-push data-responsive-width="992px" class="mdk-drawer-layout js-mdk-drawer-layout">
            <div class="mdk-drawer-layout__content page ">

                <div class="container-fluid page__container">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="admin-dashboard.html">Home</a></li>
                        <li class="breadcrumb-item active">Add Courses</li>
                    </ol>
                        <?php
                        
                        if($this->session->flashdata('error') ||  validation_errors()){ ?>
                                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                       <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                           <span aria-hidden="true">×</span>
                                       </button>
                                       <?php echo $this->session->flashdata('error'); ?>
                                       <?php echo validation_errors(); ?> 
                                   </div>
                                <?php } ?>
                                <?php if($this->session->flashdata('success')){ ?>  
                                   <div class="alert alert-success alert-dismissible fade show" role="alert">
                                       <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                           <span aria-hidden="true">×</span>
                                       </button>
                                      <?php echo $this->session->flashdata('success'); ?>
                                   </div>
                                <?php } ?>
            <form action="<?php echo site_url('admin/add_new_course'); ?>" class="was-validated" enctype="multipart/form-data" method="post" accept-charset="utf-8">
                    <div class="media align-items-center mb-headings">
                        <div class="media-body">
                            <h1 class="h2">Add Course</h1>
                        </div>
                        <div class="media-right">
                            <input type="submit"  class="btn btn-danger" value="Submit">
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">

                                <div class="form-group row">
                                    <label for="preview" class="col-sm-3 col-form-label form-label">Preview</label>
                                    <div class="col-sm-9">
                                        <div class="media align-items-center">
                                            <div class="media-left">
                                                <img src="<?php echo base_url(); ?>admin-assets/images/vuejs.png" alt="" width="100" id="photo211" class="rounded">
                                            </div>
                                            <div class="media-body">
                                                <div class="custom-file" style="width: auto;">
                                                    <input type="file" id="preview" class="custom-file-input" name="images" required="">
                                                    <label for="preview" class="custom-file-label">Choose file</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="title" class="col-md-3 col-form-label form-label">Title</label>
                                    <div class="col-md-6">
                                        <input id="title" type="text" class="form-control" name="title" placeholder="Write an awesome title" required="">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="course" class="col-md-3 col-form-label form-label">Course</label>
                                    <div class="col-md-4">
                                         
                                        <select id="course" class="custom-control custom-select form-control" name="course" required="">
                                            <?php foreach ($all_category as  $cate): ?>
                                             <option value="<?php echo $cate->id; ?>"><?php echo $cate->category; ?></option>
                                            <?php endforeach ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label form-label">Upload Video</label>
                                    <div class="col-md-9">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" value="" required="" name="videoid" />
                                                    <small class="form-text text-muted d-flex align-items-center">
                                                        <i class="material-icons font-size-16pt mr-1">ondemand_video</i>
                                                        <span class="icon-text">Paste Video</span>
                                                    </small>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <div class="embed-responsive embed-responsive-16by9">
                                                        <iframe class="embed-responsive-item" src="https://player.vimeo.com/video/97243285?title=0&amp;byline=0&amp;portrait=0" allowfullscreen=""></iframe>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                       <!--  <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="file" class="form-control" />
                                                    <small class="form-text text-muted d-flex align-items-center">
                                                        <i class="material-icons font-size-16pt mr-1">ondemand_video</i>
                                                        <span class="icon-text">Browse and Upload Video</span>
                                                    </small>
                                                </div>
                                            </div>
                                        </div> -->
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="course" class="col-md-3 col-form-label form-label">Upload Document</label>
                                    <div class="col-md-4">
                                        <input type="file" class="form-control" name="files" required="" />
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="duration" class="col-md-3 col-form-label form-label">Duration</label>
                                    <div class="col-md-6">
                                        <input id="duration" type="text" class="form-control" name="duration" placeholder="Enter total duration of the course" required="">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="course" class="col-md-3 col-form-label form-label">Brief Description</label>
                                    <div class="col-md-6">
                                        <textarea type="text" class="form-control" rows="4" name="descri" placeholder="Enter content" required=""></textarea>
                                    </div>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>

            </div>


         

                
 <?php $this->load->view('inc/sidebar'); ?>   

<?php $this->load->view('inc/footer'); ?>