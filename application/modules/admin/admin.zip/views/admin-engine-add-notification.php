<?php $this->load->view('inc/header'); ?>

    <!-- Header Layout Content -->
    <div class="mdk-header-layout__content">

        <div data-push data-responsive-width="992px" class="mdk-drawer-layout js-mdk-drawer-layout">
            <div class="mdk-drawer-layout__content page ">

                <div class="container-fluid page__container">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="admin-dashboard.html">Home</a></li>
                        <li class="breadcrumb-item"><a href="#">Event Engine</a></li>
                        <li class="breadcrumb-item active">Add Notification</li>
                    </ol>
                    <div class="media align-items-center mb-headings">
                        <div class="media-body">
                            <h1 class="h2">Add Notification</h1>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                    <br>
                    <form action="#">

                        <div class="card">
                            <div class="card-body">
                                <div class="form-group m-0" role="group" aria-labelledby="label-question">
                                    <div class="form-row align-items-center">
                                        <label id="label-question" for="question" class="col-md-3 col-form-label form-label">Subject</label>
                                        <div class="col-md-9">
                                            <input id="question" type="text" placeholder="Notification Subject ..." class="form-control">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card">
                           <div class="card-body">
                               <div class="search-form search-form--light mb-3">
                                   <input type="text" class="form-control search" placeholder="Search">
                                   <button class="btn" type="button" role="button"><i class="material-icons">search</i></button>
                               </div>

                               <div class="table-responsive border-bottom" data-toggle="lists" data-lists-values='["js-lists-values-employee-name"]'>

                                   <table class="table mb-0">
                                       <thead>
                                       <tr>

                                           <th style="width: 18px;">
                                               <div class="custom-control custom-checkbox">
                                                   <input type="checkbox" class="custom-control-input js-toggle-check-all" data-target="#staff" id="customCheckAll">
                                                   <label class="custom-control-label" for="customCheckAll"><span class="text-hide">Toggle all</span></label>
                                               </div>
                                           </th>

                                           <th>Group</th>


                                           <th style="width: 100px;">Type</th>
                                       </tr>
                                       </thead>
                                       <tbody class="list" id="staff">

                                       <tr class="selected">

                                           <td>
                                               <div class="custom-control custom-checkbox">
                                                   <input type="checkbox" class="custom-control-input js-check-selected-row" checked="" id="customCheck1_1">
                                                   <label class="custom-control-label" for="customCheck1_1"><span class="text-hide">Check</span></label>
                                               </div>
                                           </td>

                                           <td>

                                               <div class="media align-items-center">
                                                   <div class="avatar avatar-sm mr-3">
                                                       <img src="<?php echo base_url(); ?>admin-assets/images/256_rsz_nicolas-horn-689011-unsplash.jpg" alt="Avatar" class="avatar-img rounded-circle">
                                                   </div>
                                                   <div class="media-body">
                                                       <span class="js-lists-values-employee-name">Kalum Atherton</span>
                                                   </div>
                                               </div>
                                           </td>


                                           <td><small class="text-muted">A</small></td>
                                       </tr>

                                       <tr>
                                           <td>
                                               <div class="custom-control custom-checkbox">
                                                   <input type="checkbox" class="custom-control-input js-check-selected-row" id="customCheck1_2">
                                                   <label class="custom-control-label" for="customCheck1_2"><span class="text-hide">Check</span></label>
                                               </div>
                                           </td>

                                           <td>
                                               <div class="media align-items-center">
                                                   <div class="avatar avatar-sm mr-3">
                                                       <img src="<?php echo base_url(); ?>admin-assets/images/256_rsz_sharina-mae-agellon-377466-unsplash.jpg" alt="Avatar" class="avatar-img rounded-circle">
                                                   </div>
                                                   <div class="media-body">
                                                       <span class="js-lists-values-employee-name">Helen Mcdaniel</span>
                                                   </div>
                                               </div>
                                           </td>

                                           <td><small class="text-muted">B</small></td>
                                       </tr>

                                       <tr>

                                           <td>
                                               <div class="custom-control custom-checkbox">
                                                   <input type="checkbox" class="custom-control-input js-check-selected-row" id="customCheck1_3">
                                                   <label class="custom-control-label" for="customCheck1_3"><span class="text-hide">Check</span></label>
                                               </div>
                                           </td>

                                           <td>
                                               <div class="media align-items-center">
                                                   <div class="avatar avatar-sm mr-3">
                                                       <img src="<?php echo base_url(); ?>admin-assets/images/256_rsz_karl-s-973833-unsplash.jpg" alt="Avatar" class="avatar-img rounded-circle">
                                                   </div>
                                                   <div class="media-body">

                                                       <span class="js-lists-values-employee-name">Karim Hicks</span>

                                                   </div>
                                               </div>
                                           </td>
                                           <td><small class="text-muted">C</small></td>
                                       </tr>

                                       <tr>
                                           <td>
                                               <div class="custom-control custom-checkbox">
                                                   <input type="checkbox" class="custom-control-input js-check-selected-row" id="customCheck1_4">
                                                   <label class="custom-control-label" for="customCheck1_4"><span class="text-hide">Check</span></label>
                                               </div>
                                           </td>

                                           <td>
                                               <div class="media align-items-center">
                                                   <div class="avatar avatar-sm mr-3">
                                                       <img src="<?php echo base_url(); ?>admin-assets/images/256_rsz_90-jiang-640827-unsplash.jpg" alt="Avatar" class="avatar-img rounded-circle">
                                                   </div>
                                                   <div class="media-body">

                                                       <span class="js-lists-values-employee-name">Clifford Burgess</span>

                                                   </div>
                                               </div>
                                           </td>

                                           <td><small class="text-muted">D</small></td>
                                       </tr>

                                       </tbody>
                                   </table>
                               </div>

                           </div>
                        </div>

                        <div class="card">
                            <div class="list-group list-group-fit">
                                <div class="list-group-item">
                                    <div role="group" aria-labelledby="label-question" class="m-0 form-group">
                                        <div class="form-row">
                                            <label for="question" class="col-md-3 col-form-label form-label">Information</label>
                                            <div class="col-md-9">
                                                <textarea placeholder="Enter the Information..." rows="4" class="form-control"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="list-group-item">
                                    <div class="form-group m-0" role="group" aria-labelledby="label-topic">
                                        <div class="form-row align-items-center">
                                            <label id="label-topic" for="topic" class="col-md-3 col-form-label form-label">Topic</label>
                                            <div class="col-md-9">
                                                <select id="topic" class="form-control custom-select w-auto">
                                                    <option value="JavaScript">JavaScript</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="list-group-item">
                                    <div role="group" aria-labelledby="label-question" class="m-0 form-group">
                                        <div class="form-row">
                                            <label for="question" class="col-md-3 col-form-label form-label">Upload Document</label>
                                            <div class="col-md-9">
                                                <input type="file" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="list-group-item">
                                    <div class="custom-control custom-checkbox custom-control-inline">
                                        <input id="notify" type="checkbox" class="custom-control-input" checked="">
                                        <label for="notify" class="custom-control-label">Notify me on email when someone replies to my question</label>
                                    </div>
                                    <small id="description-notify" class="form-text text-muted">If unchecked, you'll still recieve notifications on our website.</small>
                                </div>
                                <div class="list-group-item">
                                    <button type="button" class="btn btn-danger">Send Notification</button>
                                </div>
                            </div>
                        </div>

                    </form>

                </div>

            </div>

<?php $this->load->view('inc/sidebar'); ?>   

<?php $this->load->view('inc/footer'); ?>